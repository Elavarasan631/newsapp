import 'package:flutter/material.dart';
import '../presentation/categories/categories.dart';
import '../presentation/article_detail/article_detail.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String categories = '/categories';
  static const String articleDetail = '/article-detail';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const Categories(),
    categories: (context) => const Categories(),
    articleDetail: (context) => const ArticleDetail(),
    // TODO: Add your other routes here
  };
}
