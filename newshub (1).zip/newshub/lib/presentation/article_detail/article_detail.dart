import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/article_content_widget.dart';
import './widgets/article_header_widget.dart';
import './widgets/bottom_toolbar_widget.dart';
import './widgets/hero_image_widget.dart';
import './widgets/reading_progress_widget.dart';
import './widgets/related_articles_widget.dart';

class ArticleDetail extends StatefulWidget {
  const ArticleDetail({super.key});

  @override
  State<ArticleDetail> createState() => _ArticleDetailState();
}

class _ArticleDetailState extends State<ArticleDetail> {
  final ScrollController _scrollController = ScrollController();
  double _scrollOffset = 0.0;
  double _readingProgress = 0.0;
  bool _showProgress = false;
  bool _isBookmarked = false;
  double _textSize = 0.0; // -2 (small), 0 (medium), 2 (large)
  bool _isDarkMode = false;

  // Mock article data
  final Map<String, dynamic> _articleData = {
    "id": 1,
    "title":
        "The Future of Artificial Intelligence: Transforming Industries and Reshaping Society",
    "author": "Dr. Sarah Chen",
    "publishedDate": "July 25, 2025",
    "readTime": "8",
    "category": "Technology",
    "imageUrl":
        "https://images.unsplash.com/photo-1677442136019-21780ecad995?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    "content":
        """Artificial Intelligence has evolved from a concept in science fiction to a transformative force reshaping every aspect of our modern world. As we stand at the precipice of an AI-driven future, it's crucial to understand both the immense opportunities and significant challenges that lie ahead.

The current state of AI technology represents decades of research and development, culminating in systems that can process natural language, recognize patterns, and make decisions with unprecedented accuracy. Machine learning algorithms now power everything from recommendation systems to autonomous vehicles, fundamentally changing how we interact with technology.

In healthcare, AI is revolutionizing diagnosis and treatment. Advanced imaging systems can detect cancers earlier than human radiologists, while predictive models help identify patients at risk of complications. Drug discovery, traditionally a process taking decades, is being accelerated through AI-powered molecular analysis and simulation.

The financial sector has embraced AI for fraud detection, algorithmic trading, and personalized banking services. Risk assessment models now incorporate vast amounts of data to make more accurate lending decisions, while chatbots handle routine customer inquiries with increasing sophistication.

Manufacturing industries are experiencing a renaissance through AI-driven automation and predictive maintenance. Smart factories optimize production schedules in real-time, reducing waste and improving efficiency. Quality control systems powered by computer vision can detect defects invisible to the human eye.

However, this technological revolution brings significant challenges. Job displacement concerns are valid as AI systems become capable of performing tasks traditionally done by humans. The need for workforce retraining and education reform has never been more urgent.

Privacy and security concerns loom large as AI systems require vast amounts of personal data to function effectively. Ensuring that this data is protected while maintaining the benefits of AI services requires careful balance and robust regulatory frameworks.

Ethical considerations around AI decision-making are equally important. As these systems influence hiring decisions, loan approvals, and even criminal justice outcomes, ensuring fairness and preventing bias becomes critical for maintaining social trust.

The future of AI will likely see even more integration into daily life. Smart cities will use AI to optimize traffic flow, energy consumption, and public services. Personal AI assistants will become more sophisticated, helping with complex tasks and decision-making.

Education will be transformed through personalized learning systems that adapt to individual student needs. Climate change mitigation efforts will benefit from AI-powered optimization of renewable energy systems and carbon capture technologies.

As we navigate this AI-driven future, collaboration between technologists, policymakers, and society at large will be essential. The goal should be to harness AI's potential while addressing its challenges, ensuring that the benefits are distributed equitably across all segments of society.

The journey ahead is complex, but the potential for positive transformation is immense. By approaching AI development with wisdom, caution, and a commitment to human welfare, we can create a future where artificial intelligence serves as a powerful tool for human flourishing.""",
  };

  final List<Map<String, dynamic>> _relatedArticles = [
    {
      "id": 2,
      "title": "Machine Learning Breakthroughs in Medical Diagnosis",
      "category": "Healthcare",
      "publishedDate": "July 23, 2025",
      "readTime": "6",
      "imageUrl":
          "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    },
    {
      "id": 3,
      "title": "Autonomous Vehicles: The Road to Full Automation",
      "category": "Transportation",
      "publishedDate": "July 22, 2025",
      "readTime": "7",
      "imageUrl":
          "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    },
    {
      "id": 4,
      "title": "AI Ethics: Building Responsible Technology",
      "category": "Ethics",
      "publishedDate": "July 20, 2025",
      "readTime": "5",
      "imageUrl":
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadPreferences();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isBookmarked =
          prefs.getBool('article_${_articleData['id']}_bookmarked') ?? false;
      _textSize = prefs.getDouble('text_size') ?? 0.0;
      _isDarkMode = prefs.getBool('dark_mode') ?? false;
    });
  }

  void _onScroll() {
    final offset = _scrollController.offset;
    final maxScroll = _scrollController.position.maxScrollExtent;

    setState(() {
      _scrollOffset = offset;
      _readingProgress =
          maxScroll > 0 ? (offset / maxScroll).clamp(0.0, 1.0) : 0.0;
      _showProgress = offset > 100;
    });
  }

  void _toggleBookmark() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isBookmarked = !_isBookmarked;
    });
    await prefs.setBool(
        'article_${_articleData['id']}_bookmarked', _isBookmarked);

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isBookmarked
            ? 'Article saved for offline reading'
            : 'Article removed from saved'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _shareArticle() {
    HapticFeedback.lightImpact();
    final shareText =
        '${_articleData['title']}\n\nRead more: https://newshub.com/article/${_articleData['id']}';

    // In a real app, this would use the share plugin
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Share functionality would open native share sheet'),
        action: SnackBarAction(
          label: 'Copy Link',
          onPressed: () {
            Clipboard.setData(ClipboardData(text: shareText));
          },
        ),
      ),
    );
  }

  void _adjustTextSize() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: Theme.of(context).dividerColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              'Text Size',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 3.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildTextSizeOption('Small', -2),
                _buildTextSizeOption('Medium', 0),
                _buildTextSizeOption('Large', 2),
              ],
            ),
            SizedBox(height: 3.h),
          ],
        ),
      ),
    );
  }

  Widget _buildTextSizeOption(String label, double size) {
    final isSelected = _textSize == size;
    return GestureDetector(
      onTap: () async {
        setState(() {
          _textSize = size;
        });
        final prefs = await SharedPreferences.getInstance();
        await prefs.setDouble('text_size', size);
        Navigator.pop(context);
        HapticFeedback.lightImpact();
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.getAccentColor(_isDarkMode).withValues(alpha: 0.1)
              : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isSelected
                ? AppTheme.getAccentColor(_isDarkMode)
                : Theme.of(context).dividerColor,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Text(
              'Aa',
              style: TextStyle(
                fontSize: (16 + size).sp,
                fontWeight: FontWeight.w600,
                color: isSelected
                    ? AppTheme.getAccentColor(_isDarkMode)
                    : Theme.of(context).primaryColor,
              ),
            ),
            SizedBox(height: 0.5.h),
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: isSelected
                        ? AppTheme.getAccentColor(_isDarkMode)
                        : Theme.of(context).textTheme.bodySmall?.color,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  ),
            ),
          ],
        ),
      ),
    );
  }

  void _showMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: Theme.of(context).dividerColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 2.h),
            _buildMenuOption('Report Article', 'flag', () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Article reported')),
              );
            }),
            _buildMenuOption('View Source', 'open_in_new', () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Would open source website')),
              );
            }),
            _buildMenuOption('Categories', 'category', () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/categories');
            }),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuOption(String title, String iconName, VoidCallback onTap) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: iconName,
        color: Theme.of(context).primaryColor,
        size: 24,
      ),
      title: Text(
        title,
        style: Theme.of(context).textTheme.bodyLarge,
      ),
      onTap: onTap,
    );
  }

  void _onRelatedArticleTap(Map<String, dynamic> article) {
    // In a real app, this would navigate to the selected article
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Would navigate to: ${article['title']}'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Main Content
          CustomScrollView(
            controller: _scrollController,
            slivers: [
              // Hero Image with Header
              SliverToBoxAdapter(
                child: Stack(
                  children: [
                    HeroImageWidget(
                      imageUrl: _articleData['imageUrl'] as String,
                      scrollOffset: _scrollOffset,
                    ),
                    Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      child: ArticleHeaderWidget(
                        onBackPressed: () => Navigator.pop(context),
                        onSharePressed: _shareArticle,
                        onBookmarkPressed: _toggleBookmark,
                        onMenuPressed: _showMenu,
                        isBookmarked: _isBookmarked,
                      ),
                    ),
                  ],
                ),
              ),

              // Article Content
              SliverToBoxAdapter(
                child: Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(16)),
                  ),
                  child: ArticleContentWidget(
                    title: _articleData['title'] as String,
                    author: _articleData['author'] as String,
                    publishedDate: _articleData['publishedDate'] as String,
                    readTime: _articleData['readTime'] as String,
                    content: _articleData['content'] as String,
                    textSize: _textSize,
                    isDarkMode: _isDarkMode,
                  ),
                ),
              ),

              // Related Articles
              SliverToBoxAdapter(
                child: Container(
                  color: Theme.of(context).scaffoldBackgroundColor,
                  child: RelatedArticlesWidget(
                    relatedArticles: _relatedArticles,
                    onArticleTap: _onRelatedArticleTap,
                  ),
                ),
              ),

              // Bottom spacing for toolbar
              SliverToBoxAdapter(
                child: SizedBox(height: 12.h),
              ),
            ],
          ),

          // Reading Progress Indicator
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: ReadingProgressWidget(
              progress: _readingProgress,
              isVisible: _showProgress,
            ),
          ),

          // Bottom Toolbar
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: BottomToolbarWidget(
              isBookmarked: _isBookmarked,
              onBookmarkPressed: _toggleBookmark,
              onSharePressed: _shareArticle,
              onTextSizePressed: _adjustTextSize,
              textSize: _textSize,
            ),
          ),
        ],
      ),
    );
  }
}
