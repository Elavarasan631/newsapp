import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ArticleContentWidget extends StatelessWidget {
  final String title;
  final String author;
  final String publishedDate;
  final String readTime;
  final String content;
  final double textSize;
  final bool isDarkMode;

  const ArticleContentWidget({
    super.key,
    required this.title,
    required this.author,
    required this.publishedDate,
    required this.readTime,
    required this.content,
    required this.textSize,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Article Title
          GestureDetector(
            onLongPress: () => _showTextSelection(context, title),
            child: Text(
              title,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontSize: (20 + textSize).sp,
                    fontWeight: FontWeight.w700,
                    height: 1.3,
                  ),
            ),
          ),
          SizedBox(height: 2.h),

          // Article Metadata
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'By $author',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            fontSize: (14 + textSize * 0.5).sp,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.getAccentColor(isDarkMode),
                          ),
                    ),
                    SizedBox(height: 0.5.h),
                    Row(
                      children: [
                        Text(
                          publishedDate,
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    fontSize: (12 + textSize * 0.3).sp,
                                    color: isDarkMode
                                        ? AppTheme.textMediumEmphasisDark
                                        : AppTheme.textMediumEmphasisLight,
                                  ),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(horizontal: 2.w),
                          width: 1,
                          height: 1.h,
                          color: isDarkMode
                              ? AppTheme.textDisabledDark
                              : AppTheme.textDisabledLight,
                        ),
                        CustomIconWidget(
                          iconName: 'access_time',
                          color: isDarkMode
                              ? AppTheme.textMediumEmphasisDark
                              : AppTheme.textMediumEmphasisLight,
                          size: 12,
                        ),
                        SizedBox(width: 1.w),
                        Text(
                          '$readTime min read',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    fontSize: (12 + textSize * 0.3).sp,
                                    color: isDarkMode
                                        ? AppTheme.textMediumEmphasisDark
                                        : AppTheme.textMediumEmphasisLight,
                                  ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),

          // Article Content
          GestureDetector(
            onLongPress: () => _showTextSelection(context, content),
            child: SelectableText(
              content,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    fontSize: (16 + textSize).sp,
                    height: 1.7,
                    letterSpacing: 0.2,
                  ),
              textAlign: TextAlign.justify,
            ),
          ),
          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  void _showTextSelection(BuildContext context, String text) {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: Theme.of(context).dividerColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 2.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildActionButton(
                  context,
                  'Copy',
                  'content_copy',
                  () {
                    Clipboard.setData(ClipboardData(text: text));
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Text copied to clipboard')),
                    );
                  },
                ),
                _buildActionButton(
                  context,
                  'Share',
                  'share',
                  () {
                    Navigator.pop(context);
                    // Share functionality would be implemented here
                  },
                ),
              ],
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton(
    BuildContext context,
    String label,
    String iconName,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 1.5.h),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: Theme.of(context).dividerColor,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: iconName,
              color: Theme.of(context).primaryColor,
              size: 18,
            ),
            SizedBox(width: 2.w),
            Text(
              label,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
