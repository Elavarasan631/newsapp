import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_image_widget.dart';

class HeroImageWidget extends StatelessWidget {
  final String imageUrl;
  final double scrollOffset;

  const HeroImageWidget({
    super.key,
    required this.imageUrl,
    required this.scrollOffset,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 35.h,
      width: double.infinity,
      child: Stack(
        children: [
          Transform.translate(
            offset: Offset(0, scrollOffset * 0.5),
            child: Container(
              height: 40.h,
              width: double.infinity,
              child: CustomImageWidget(
                imageUrl: imageUrl,
                width: double.infinity,
                height: 40.h,
                fit: BoxFit.cover,
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 15.h,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.8),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
