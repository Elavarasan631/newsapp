import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RelatedArticlesWidget extends StatelessWidget {
  final List<Map<String, dynamic>> relatedArticles;
  final Function(Map<String, dynamic>) onArticleTap;

  const RelatedArticlesWidget({
    super.key,
    required this.relatedArticles,
    required this.onArticleTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Text(
              'Related Articles',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ),
          SizedBox(height: 2.h),
          Container(
            height: 25.h,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              itemCount: relatedArticles.length,
              separatorBuilder: (context, index) => SizedBox(width: 3.w),
              itemBuilder: (context, index) {
                final article = relatedArticles[index];
                return _buildRelatedArticleCard(context, article);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRelatedArticleCard(
      BuildContext context, Map<String, dynamic> article) {
    return GestureDetector(
      onTap: () => onArticleTap(article),
      child: Container(
        width: 70.w,
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Theme.of(context).shadowColor,
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Article Image
            Container(
              height: 12.h,
              width: double.infinity,
              child: ClipRRect(
                borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                child: CustomImageWidget(
                  imageUrl: article['imageUrl'] as String,
                  width: double.infinity,
                  height: 12.h,
                  fit: BoxFit.cover,
                ),
              ),
            ),

            // Article Content
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(3.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Category
                    Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 2.w, vertical: 0.5.h),
                      decoration: BoxDecoration(
                        color: AppTheme.getAccentColor(
                                Theme.of(context).brightness == Brightness.dark)
                            .withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        article['category'] as String,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontSize: 10.sp,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.getAccentColor(
                                  Theme.of(context).brightness ==
                                      Brightness.dark),
                            ),
                      ),
                    ),
                    SizedBox(height: 1.h),

                    // Title
                    Expanded(
                      child: Text(
                        article['title'] as String,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w600,
                              height: 1.3,
                            ),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),

                    // Metadata
                    Row(
                      children: [
                        Text(
                          article['publishedDate'] as String,
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    fontSize: 10.sp,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? AppTheme.textMediumEmphasisDark
                                        : AppTheme.textMediumEmphasisLight,
                                  ),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(horizontal: 1.w),
                          width: 1,
                          height: 1.h,
                          color: Theme.of(context).dividerColor,
                        ),
                        Text(
                          '${article['readTime']} min',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    fontSize: 10.sp,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? AppTheme.textMediumEmphasisDark
                                        : AppTheme.textMediumEmphasisLight,
                                  ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
