import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class ReadingProgressWidget extends StatelessWidget {
  final double progress;
  final bool isVisible;

  const ReadingProgressWidget({
    super.key,
    required this.progress,
    required this.isVisible,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: isVisible ? 1.0 : 0.0,
      duration: Duration(milliseconds: 300),
      child: Container(
        height: 0.5.h,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Theme.of(context).dividerColor,
        ),
        child: FractionallySizedBox(
          alignment: Alignment.centerLeft,
          widthFactor: progress.clamp(0.0, 1.0),
          child: Container(
            decoration: BoxDecoration(
              color: AppTheme.getAccentColor(
                  Theme.of(context).brightness == Brightness.dark),
            ),
          ),
        ),
      ),
    );
  }
}
