import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BottomToolbarWidget extends StatelessWidget {
  final bool isBookmarked;
  final VoidCallback onBookmarkPressed;
  final VoidCallback onSharePressed;
  final VoidCallback onTextSizePressed;
  final double textSize;

  const BottomToolbarWidget({
    super.key,
    required this.isBookmarked,
    required this.onBookmarkPressed,
    required this.onSharePressed,
    required this.onTextSizePressed,
    required this.textSize,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 10.h,
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).dividerColor,
            width: 1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).shadowColor,
            blurRadius: 8,
            offset: Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 1.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildToolbarButton(
                context,
                iconName: isBookmarked ? 'bookmark' : 'bookmark_border',
                label: isBookmarked ? 'Saved' : 'Save',
                onTap: onBookmarkPressed,
                isActive: isBookmarked,
              ),
              _buildToolbarButton(
                context,
                iconName: 'share',
                label: 'Share',
                onTap: onSharePressed,
              ),
              _buildToolbarButton(
                context,
                iconName: 'text_fields',
                label: 'Text Size',
                onTap: onTextSizePressed,
                badge: _getTextSizeLabel(textSize),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildToolbarButton(
    BuildContext context, {
    required String iconName,
    required String label,
    required VoidCallback onTap,
    bool isActive = false,
    String? badge,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: isActive
              ? AppTheme.getAccentColor(
                      Theme.of(context).brightness == Brightness.dark)
                  .withValues(alpha: 0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              children: [
                CustomIconWidget(
                  iconName: iconName,
                  color: isActive
                      ? AppTheme.getAccentColor(
                          Theme.of(context).brightness == Brightness.dark)
                      : Theme.of(context).primaryColor,
                  size: 24,
                ),
                if (badge != null)
                  Positioned(
                    right: -2,
                    top: -2,
                    child: Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 1.w, vertical: 0.2.h),
                      decoration: BoxDecoration(
                        color: AppTheme.getAccentColor(
                            Theme.of(context).brightness == Brightness.dark),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        badge,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 8.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 0.5.h),
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w500,
                    color: isActive
                        ? AppTheme.getAccentColor(
                            Theme.of(context).brightness == Brightness.dark)
                        : Theme.of(context).textTheme.bodySmall?.color,
                  ),
            ),
          ],
        ),
      ),
    );
  }

  String _getTextSizeLabel(double size) {
    if (size <= -2) return 'S';
    if (size >= 2) return 'L';
    return 'M';
  }
}
