import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class CategoryManagementSheetWidget extends StatefulWidget {
  final Map<String, dynamic> category;
  final VoidCallback onHide;
  final VoidCallback onMoveToTop;
  final VoidCallback onNotificationSettings;

  const CategoryManagementSheetWidget({
    Key? key,
    required this.category,
    required this.onHide,
    required this.onMoveToTop,
    required this.onNotificationSettings,
  }) : super(key: key);

  @override
  State<CategoryManagementSheetWidget> createState() =>
      _CategoryManagementSheetWidgetState();
}

class _CategoryManagementSheetWidgetState
    extends State<CategoryManagementSheetWidget> {
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Container(
            margin: EdgeInsets.only(top: 1.h),
            width: 10.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: isDark ? AppTheme.borderDark : AppTheme.borderLight,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          SizedBox(height: 2.h),

          // Category header
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color:
                        AppTheme.getAccentColor(isDark).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: CustomIconWidget(
                    iconName: widget.category["icon"] as String,
                    color: AppTheme.getAccentColor(isDark),
                    size: 6.w,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.category["name"] as String,
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      Text(
                        "${widget.category["articleCount"]} articles",
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: isDark
                                  ? AppTheme.textMediumEmphasisDark
                                  : AppTheme.textMediumEmphasisLight,
                            ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          // Action options
          _buildActionTile(
            context,
            icon: 'visibility_off',
            title: 'Hide Category',
            subtitle: 'Remove from your categories list',
            onTap: () {
              Navigator.pop(context);
              widget.onHide();
            },
          ),

          _buildActionTile(
            context,
            icon: 'keyboard_arrow_up',
            title: 'Move to Top',
            subtitle: 'Pin this category at the top',
            onTap: () {
              Navigator.pop(context);
              widget.onMoveToTop();
            },
          ),

          _buildActionTile(
            context,
            icon: 'notifications',
            title: 'Notification Settings',
            subtitle: 'Manage alerts for this category',
            onTap: () {
              Navigator.pop(context);
              widget.onNotificationSettings();
            },
          ),

          SizedBox(height: 2.h),

          // Cancel button
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel'),
              ),
            ),
          ),

          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildActionTile(
    BuildContext context, {
    required String icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ListTile(
      leading: Container(
        padding: EdgeInsets.all(2.w),
        decoration: BoxDecoration(
          color: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
          borderRadius: BorderRadius.circular(8),
        ),
        child: CustomIconWidget(
          iconName: icon,
          color: isDark
              ? AppTheme.textMediumEmphasisDark
              : AppTheme.textMediumEmphasisLight,
          size: 5.w,
        ),
      ),
      title: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium,
      ),
      subtitle: Text(
        subtitle,
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: isDark
                  ? AppTheme.textMediumEmphasisDark
                  : AppTheme.textMediumEmphasisLight,
            ),
      ),
      onTap: onTap,
      contentPadding: EdgeInsets.symmetric(horizontal: 4.w),
    );
  }
}
