import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import './category_card_widget.dart';

class CategoryGridWidget extends StatelessWidget {
  final List<Map<String, dynamic>> categories;
  final Function(Map<String, dynamic>) onCategoryTap;
  final Function(Map<String, dynamic>) onCategoryLongPress;

  const CategoryGridWidget({
    Key? key,
    required this.categories,
    required this.onCategoryTap,
    required this.onCategoryLongPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (categories.isEmpty) {
      return _buildEmptyState(context);
    }

    return GridView.builder(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 4.w,
        mainAxisSpacing: 2.h,
        childAspectRatio: 0.85,
      ),
      itemCount: categories.length,
      itemBuilder: (context, index) {
        final category = categories[index];
        return CategoryCardWidget(
          category: category,
          onTap: () => onCategoryTap(category),
          onLongPress: () => onCategoryLongPress(category),
        );
      },
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'search_off',
            color:
                isDark ? AppTheme.textDisabledDark : AppTheme.textDisabledLight,
            size: 15.w,
          ),
          SizedBox(height: 2.h),
          Text(
            "No categories found",
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: isDark
                      ? AppTheme.textMediumEmphasisDark
                      : AppTheme.textMediumEmphasisLight,
                ),
          ),
          SizedBox(height: 1.h),
          Text(
            "Try adjusting your search or filters",
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: isDark
                      ? AppTheme.textDisabledDark
                      : AppTheme.textDisabledLight,
                ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 3.h),
          TextButton(
            onPressed: () {
              // Clear search action would be handled by parent
            },
            child: Text("Clear search"),
          ),
        ],
      ),
    );
  }
}
