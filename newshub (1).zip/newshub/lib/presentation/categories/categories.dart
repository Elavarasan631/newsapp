import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/category_grid_widget.dart';
import './widgets/category_management_sheet_widget.dart';
import './widgets/category_search_bar_widget.dart';

class Categories extends StatefulWidget {
  const Categories({Key? key}) : super(key: key);

  @override
  State<Categories> createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  final TextEditingController _searchController = TextEditingController();
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      GlobalKey<RefreshIndicatorState>();

  List<Map<String, dynamic>> _allCategories = [];
  List<Map<String, dynamic>> _filteredCategories = [];
  bool _isLoading = false;

  // Mock data for categories
  final List<Map<String, dynamic>> _mockCategories = [
    {
      "id": 1,
      "name": "Politics",
      "icon": "how_to_vote",
      "articleCount": 245,
      "backgroundImage":
          "https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "isHidden": false,
      "isPinned": false,
      "notificationsEnabled": true,
    },
    {
      "id": 2,
      "name": "Technology",
      "icon": "computer",
      "articleCount": 189,
      "backgroundImage":
          "https://images.unsplash.com/photo-1518709268805-4e9042af2176?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "isHidden": false,
      "isPinned": false,
      "notificationsEnabled": true,
    },
    {
      "id": 3,
      "name": "Sports",
      "icon": "sports_soccer",
      "articleCount": 156,
      "backgroundImage":
          "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "isHidden": false,
      "isPinned": false,
      "notificationsEnabled": false,
    },
    {
      "id": 4,
      "name": "Entertainment",
      "icon": "movie",
      "articleCount": 203,
      "backgroundImage":
          "https://images.unsplash.com/photo-1489599904472-84b0e19e8b0b?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "isHidden": false,
      "isPinned": true,
      "notificationsEnabled": true,
    },
    {
      "id": 5,
      "name": "Business",
      "icon": "business",
      "articleCount": 178,
      "backgroundImage":
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "isHidden": false,
      "isPinned": false,
      "notificationsEnabled": true,
    },
    {
      "id": 6,
      "name": "Health",
      "icon": "local_hospital",
      "articleCount": 134,
      "backgroundImage":
          "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "isHidden": false,
      "isPinned": false,
      "notificationsEnabled": false,
    },
    {
      "id": 7,
      "name": "Science",
      "icon": "science",
      "articleCount": 98,
      "backgroundImage":
          "https://images.unsplash.com/photo-1532094349884-543bc11b234d?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "isHidden": false,
      "isPinned": false,
      "notificationsEnabled": true,
    },
    {
      "id": 8,
      "name": "World News",
      "icon": "public",
      "articleCount": 267,
      "backgroundImage":
          "https://images.unsplash.com/photo-1504711434969-e33886168f5c?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "isHidden": false,
      "isPinned": false,
      "notificationsEnabled": true,
    },
  ];

  @override
  void initState() {
    super.initState();
    _initializeCategories();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  void _initializeCategories() {
    setState(() {
      _allCategories = List.from(_mockCategories);
      _filteredCategories = _getSortedCategories();
    });
  }

  List<Map<String, dynamic>> _getSortedCategories() {
    final categories = _allCategories
        .where((category) => !(category["isHidden"] as bool))
        .toList();

    // Sort: pinned first, then by name
    categories.sort((a, b) {
      final aPinned = a["isPinned"] as bool;
      final bPinned = b["isPinned"] as bool;

      if (aPinned && !bPinned) return -1;
      if (!aPinned && bPinned) return 1;

      return (a["name"] as String).compareTo(b["name"] as String);
    });

    return categories;
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredCategories = _getSortedCategories();
      } else {
        _filteredCategories = _getSortedCategories()
            .where((category) =>
                (category["name"] as String).toLowerCase().contains(query))
            .toList();
      }
    });
  }

  Future<void> _onRefresh() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call to refresh article counts
    await Future.delayed(const Duration(seconds: 1));

    // Update article counts with random values to simulate refresh
    for (var category in _allCategories) {
      final currentCount = category["articleCount"] as int;
      final variation = (currentCount * 0.1).round();
      category["articleCount"] = currentCount + (variation - (variation ~/ 2));
    }

    setState(() {
      _isLoading = false;
      _filteredCategories = _getSortedCategories();
    });
  }

  void _onCategoryTap(Map<String, dynamic> category) {
    HapticFeedback.lightImpact();

    // Navigate to filtered news feed for this category
    Navigator.pushNamed(
      context,
      '/article-detail',
      arguments: {
        'categoryId': category["id"],
        'categoryName': category["name"],
      },
    );
  }

  void _onCategoryLongPress(Map<String, dynamic> category) {
    HapticFeedback.mediumImpact();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => CategoryManagementSheetWidget(
        category: category,
        onHide: () => _hideCategory(category),
        onMoveToTop: () => _moveToTop(category),
        onNotificationSettings: () => _toggleNotifications(category),
      ),
    );
  }

  void _hideCategory(Map<String, dynamic> category) {
    setState(() {
      final index = _allCategories.indexWhere((c) => c["id"] == category["id"]);
      if (index != -1) {
        _allCategories[index]["isHidden"] = true;
        _filteredCategories = _getSortedCategories();
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${category["name"]} hidden from categories'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () => _showCategory(category),
        ),
      ),
    );
  }

  void _showCategory(Map<String, dynamic> category) {
    setState(() {
      final index = _allCategories.indexWhere((c) => c["id"] == category["id"]);
      if (index != -1) {
        _allCategories[index]["isHidden"] = false;
        _filteredCategories = _getSortedCategories();
      }
    });
  }

  void _moveToTop(Map<String, dynamic> category) {
    setState(() {
      final index = _allCategories.indexWhere((c) => c["id"] == category["id"]);
      if (index != -1) {
        _allCategories[index]["isPinned"] = !(category["isPinned"] as bool);
        _filteredCategories = _getSortedCategories();
      }
    });

    final isPinned = _allCategories
        .firstWhere((c) => c["id"] == category["id"])["isPinned"] as bool;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(isPinned
            ? '${category["name"]} pinned to top'
            : '${category["name"]} unpinned'),
      ),
    );
  }

  void _toggleNotifications(Map<String, dynamic> category) {
    setState(() {
      final index = _allCategories.indexWhere((c) => c["id"] == category["id"]);
      if (index != -1) {
        _allCategories[index]["notificationsEnabled"] =
            !(category["notificationsEnabled"] as bool);
        _filteredCategories = _getSortedCategories();
      }
    });

    final enabled = _allCategories.firstWhere(
        (c) => c["id"] == category["id"])["notificationsEnabled"] as bool;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(enabled
            ? 'Notifications enabled for ${category["name"]}'
            : 'Notifications disabled for ${category["name"]}'),
      ),
    );
  }

  void _onFilterTap() {
    HapticFeedback.lightImpact();

    showModalBottomSheet(
      context: context,
      builder: (context) => _buildFilterSheet(),
    );
  }

  Widget _buildFilterSheet() {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle bar
          Center(
            child: Container(
              width: 10.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: isDark ? AppTheme.borderDark : AppTheme.borderLight,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),

          SizedBox(height: 2.h),

          Text(
            'Filter Categories',
            style: Theme.of(context).textTheme.headlineSmall,
          ),

          SizedBox(height: 2.h),

          ListTile(
            leading: CustomIconWidget(
              iconName: 'push_pin',
              color: AppTheme.getAccentColor(isDark),
              size: 6.w,
            ),
            title: Text('Show Pinned Only'),
            trailing: Switch(
              value: false,
              onChanged: (value) {
                // Implement pinned filter
                Navigator.pop(context);
              },
            ),
          ),

          ListTile(
            leading: CustomIconWidget(
              iconName: 'notifications',
              color: AppTheme.getAccentColor(isDark),
              size: 6.w,
            ),
            title: Text('Show Notifications Enabled'),
            trailing: Switch(
              value: false,
              onChanged: (value) {
                // Implement notifications filter
                Navigator.pop(context);
              },
            ),
          ),

          SizedBox(height: 2.h),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Apply Filters'),
            ),
          ),

          SizedBox(height: 1.h),
        ],
      ),
    );
  }

  void _openCategoryManagement() {
    HapticFeedback.lightImpact();

    // This would open a full category management screen
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Category management coming soon!'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor:
          isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
      body: SafeArea(
        child: Column(
          children: [
            // Search bar
            CategorySearchBarWidget(
              controller: _searchController,
              onChanged: (value) {}, // Handled by listener
              onFilterTap: _onFilterTap,
            ),

            // Categories grid
            Expanded(
              child: RefreshIndicator(
                key: _refreshIndicatorKey,
                onRefresh: _onRefresh,
                color: AppTheme.getAccentColor(isDark),
                child: CategoryGridWidget(
                  categories: _filteredCategories,
                  onCategoryTap: _onCategoryTap,
                  onCategoryLongPress: _onCategoryLongPress,
                ),
              ),
            ),
          ],
        ),
      ),

      // Floating action button for category management
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openCategoryManagement,
        icon: CustomIconWidget(
          iconName: 'tune',
          color: Colors.white,
          size: 5.w,
        ),
        label: Text(
          'Customize',
          style: Theme.of(context).textTheme.labelLarge?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
        ),
      ),
    );
  }
}
